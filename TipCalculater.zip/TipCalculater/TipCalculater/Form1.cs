﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TipCalculater
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            try
            {   
                //Use for getting value from textbox if textbox value is null then it will auto add 0 otherwise it will add user textbox value
                double bill_amount = textBox1.Text == "" ? 0 : Convert.ToDouble(textBox1.Text);

                //Use for getting value from tip box                      
                double tip = Convert.ToDouble(numericUpDown1.Value);

                //Use for getting value from number of people box 
                double num_of_person = Convert.ToDouble(numericUpDown2.Value); 
               
                //Use for finding per person tip                              
                double per_person_tip = Convert.ToDouble((Convert.ToDouble((bill_amount / Convert.ToDouble(100))) * tip) / num_of_person);

                //Use for finding per person total amount
                double total_per_person_amount = Convert.ToDouble((bill_amount + Convert.ToDouble(per_person_tip * num_of_person)) / num_of_person);

                //Use for show updated value in per person tip box and total_per_person_amount box
                label10.Text = Convert.ToString(per_person_tip);
                label11.Text = Convert.ToString(total_per_person_amount);               
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message);             
            }
                    
        }

        
       




       

        
    }
}
